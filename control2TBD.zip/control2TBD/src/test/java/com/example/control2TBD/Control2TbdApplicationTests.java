package com.example.control2TBD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Control2TbdApplicationTests {

	@Test
	void contextLoads() {
	}

}
