package com.example.control2TBD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Control2TbdApplication {

	public static void main(String[] args) {
		SpringApplication.run(Control2TbdApplication.class, args);
	}

}
